# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 5.0 | 0/3 | 0.0000 | 0.0000 | 33.7023% | 33.7023% | 否 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 10.0 | 0/3 | 0.0000 | 0.0000 | 32.3966% | 32.3966% | 否 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 15.0 | 0/3 | 0.0000 | 0.0000 | 31.3983% | 31.3983% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 5.0 | 0 | 24.1428% | 24.1428% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 5.0 | 1 | 28.4071% | 28.4071% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 5.0 | 2 | 48.5569% | 48.5569% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 10.0 | 0 | 20.0412% | 20.0412% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 10.0 | 1 | 31.3043% | 31.3043% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 10.0 | 2 | 45.8442% | 45.8442% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 15.0 | 0 | 21.7773% | 21.7773% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 15.0 | 1 | 31.6949% | 31.6949% | +0.0000 | 0 | 0 |
| `state_embedding_channel_residual_bce_replay_3s12f_5_10_15db_20261012` | 15.0 | 2 | 40.7227% | 40.7227% | +0.0000 | 0 | 0 |
