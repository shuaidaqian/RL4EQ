# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 3/5 | 0.2001 | -1.2109 | 29.0881% | 28.8880% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 0 | 23.9996% | 23.9063% | +0.0933 | 23 | 15 |
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 1 | 30.8984% | 30.9028% | -0.0043 | 14 | 11 |
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 2 | 42.9319% | 42.0573% | +0.8746 | 16 | 11 |
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 3 | 17.9080% | 19.1189% | -1.2109 | 45 | 9 |
| `state_embedding_conservative_5db_5s60f_20261011` | 5.0 | 4 | 29.7027% | 28.4549% | +1.2478 | 21 | 11 |
