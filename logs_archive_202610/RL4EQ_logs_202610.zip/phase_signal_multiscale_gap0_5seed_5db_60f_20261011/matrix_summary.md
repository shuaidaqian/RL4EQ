# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 4/5 | 0.0343 | 0.0000 | 5.7066% | 5.6723% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 0 | 5.9071% | 5.8420% | +0.0651 | 59 | 0 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 1 | 5.1497% | 5.1476% | +0.0022 | 58 | 1 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 2 | 6.8229% | 6.8229% | +0.0000 | 58 | 0 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 3 | 4.9154% | 4.9132% | +0.0022 | 58 | 1 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 4 | 5.7378% | 5.6359% | +0.1020 | 57 | 0 |
