# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 4/5 | 0.2088 | -1.2305 | 29.0881% | 28.8793% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 0 | 23.9996% | 23.9345% | +0.0651 | 24 | 15 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 1 | 30.8984% | 30.8789% | +0.0195 | 14 | 11 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 2 | 42.9319% | 42.0269% | +0.9049 | 19 | 14 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 3 | 17.9080% | 19.1385% | -1.2305 | 45 | 9 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 4 | 29.7027% | 28.4180% | +1.2847 | 22 | 12 |
