# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 4/5 | 0.2517 | -1.0677 | 25.0955% | 24.8438% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 0 | 17.3307% | 16.2500% | +1.0807 | 46 | 1 |
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 1 | 27.8516% | 27.1853% | +0.6662 | 13 | 10 |
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 2 | 42.5977% | 43.6654% | -1.0677 | 14 | 12 |
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 3 | 14.8828% | 14.8329% | +0.0499 | 53 | 1 |
| `state_embedding_moderate_drift08_15db_5s60f_20261011` | 15.0 | 4 | 22.8147% | 22.2852% | +0.5295 | 40 | 1 |
