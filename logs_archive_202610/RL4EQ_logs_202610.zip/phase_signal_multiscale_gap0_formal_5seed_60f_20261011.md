# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 0/5 | 0.0000 | 0.0000 | 21.3841% | 21.3841% | 否 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 4/5 | 0.0343 | 0.0000 | 5.7066% | 5.6723% | 否 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 0/5 | 0.0000 | 0.0000 | 0.9549% | 0.9549% | 否 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 0/5 | 0.0000 | 0.0000 | 0.1641% | 0.1641% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 0 | 21.7296% | 21.7296% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 1 | 21.3433% | 21.3433% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 2 | 23.5113% | 23.5113% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 3 | 19.1710% | 19.1710% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_0db_60f_20261011` | 0.0 | 4 | 21.1654% | 21.1654% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 0 | 5.9071% | 5.8420% | +0.0651 | 59 | 0 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 1 | 5.1497% | 5.1476% | +0.0022 | 58 | 1 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 2 | 6.8229% | 6.8229% | +0.0000 | 58 | 0 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 3 | 4.9154% | 4.9132% | +0.0022 | 58 | 1 |
| `phase_signal_multiscale_gap0_5seed_5db_60f_20261011` | 5.0 | 4 | 5.7378% | 5.6359% | +0.1020 | 57 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 0 | 0.9028% | 0.9028% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 1 | 0.5968% | 0.5968% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 2 | 1.6797% | 1.6797% | +0.0000 | 59 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 3 | 0.6402% | 0.6402% | +0.0000 | 60 | 1 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 4 | 0.9549% | 0.9549% | +0.0000 | 59 | 0 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 0 | 0.1497% | 0.1497% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 1 | 0.0716% | 0.0716% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 2 | 0.4253% | 0.4253% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 3 | 0.0781% | 0.0781% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_15db_60f_20261011` | 15.0 | 4 | 0.0955% | 0.0955% | +0.0000 | 59 | 0 |
