# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 0/5 | 0.0000 | 0.0000 | 38.9644% | 38.9644% | 否 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 4/5 | 1.0612 | -0.0629 | 29.0881% | 28.0269% | 否 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 5/5 | 0.9718 | 0.0716 | 26.6133% | 25.6415% | 否 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 3/5 | 0.0243 | -1.0677 | 25.0955% | 25.0712% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 0 | 37.9666% | 37.9666% | +0.0000 | 60 | 0 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 1 | 39.3273% | 39.3273% | +0.0000 | 60 | 0 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 2 | 44.9154% | 44.9154% | +0.0000 | 60 | 0 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 3 | 31.6536% | 31.6536% | +0.0000 | 60 | 0 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 0.0 | 4 | 40.9592% | 40.9592% | +0.0000 | 60 | 0 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 0 | 23.9996% | 23.9149% | +0.0846 | 19 | 13 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 1 | 30.8984% | 29.5573% | +1.3411 | 12 | 11 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 2 | 42.9319% | 41.7057% | +1.2261 | 10 | 9 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 3 | 17.9080% | 17.9709% | -0.0629 | 44 | 8 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 5.0 | 4 | 29.7027% | 26.9857% | +2.7170 | 13 | 8 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 0 | 18.5807% | 18.0208% | +0.5599 | 16 | 12 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 1 | 27.9622% | 26.1762% | +1.7860 | 9 | 8 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 2 | 43.9497% | 42.9818% | +0.9679 | 17 | 11 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 3 | 18.1814% | 18.1098% | +0.0716 | 47 | 3 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 10.0 | 4 | 24.3924% | 22.9188% | +1.4735 | 11 | 5 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 0 | 17.3307% | 16.3520% | +0.9787 | 12 | 9 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 1 | 27.8516% | 27.1853% | +0.6662 | 13 | 10 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 2 | 42.5977% | 43.6654% | -1.0677 | 14 | 12 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 3 | 14.8828% | 14.8112% | +0.0716 | 48 | 2 |
| `state_embedding_formal_moderate_5s60f_0_5_10_15db_20261011` | 15.0 | 4 | 22.8147% | 23.3420% | -0.5273 | 12 | 9 |
