# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 0/5 | 0.0000 | 0.0000 | 38.9644% | 38.9644% | 否 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 4/5 | 0.2088 | -1.2305 | 29.0881% | 28.8793% | 否 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 4/5 | 0.5182 | -0.0043 | 26.6133% | 26.0951% | 否 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 4/5 | 0.3438 | -0.1497 | 25.0955% | 24.7517% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 0 | 37.9666% | 37.9666% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 1 | 39.3273% | 39.3273% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 2 | 44.9154% | 44.9154% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 3 | 31.6536% | 31.6536% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 4 | 40.9592% | 40.9592% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 0 | 23.9996% | 23.9345% | +0.0651 | 24 | 15 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 1 | 30.8984% | 30.8789% | +0.0195 | 14 | 11 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 2 | 42.9319% | 42.0269% | +0.9049 | 19 | 14 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 3 | 17.9080% | 19.1385% | -1.2305 | 45 | 9 |
| `phase_signal_multiscale_gap600_5seed_5db_60f_20261011` | 5.0 | 4 | 29.7027% | 28.4180% | +1.2847 | 22 | 12 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 0 | 18.5807% | 18.4570% | +0.1237 | 20 | 16 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 1 | 27.9622% | 26.8294% | +1.1328 | 13 | 10 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 2 | 43.9497% | 43.7695% | +0.1801 | 19 | 13 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 3 | 18.1814% | 18.1858% | -0.0043 | 48 | 3 |
| `phase_signal_multiscale_gap600_5seed_10db_60f_20261011` | 10.0 | 4 | 24.3924% | 23.2335% | +1.1589 | 13 | 7 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 0 | 17.3307% | 17.4805% | -0.1497 | 18 | 12 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 1 | 27.8516% | 27.1658% | +0.6858 | 17 | 15 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 2 | 42.5977% | 42.3329% | +0.2648 | 19 | 15 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 3 | 14.8828% | 14.8286% | +0.0543 | 49 | 2 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 4 | 22.8147% | 21.9510% | +0.8637 | 16 | 9 |
