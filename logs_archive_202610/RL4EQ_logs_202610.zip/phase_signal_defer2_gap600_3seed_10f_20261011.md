# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_defer2_gap600_3seed_10f_20261011_5db` | 5.0 | 0/3 | -0.0087 | -0.0260 | 33.5373% | 33.5460% | 否 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_10db` | 10.0 | 0/3 | 0.0000 | 0.0000 | 30.9201% | 30.9201% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_defer2_gap600_3seed_10f_20261011_5db` | 5.0 | 0 | 24.9479% | 24.9740% | -0.0260 | 0 | 1 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_5db` | 5.0 | 1 | 29.4922% | 29.4922% | -0.0000 | 0 | 1 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_5db` | 5.0 | 2 | 46.1719% | 46.1719% | +0.0000 | 0 | 0 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_10db` | 10.0 | 0 | 16.9792% | 16.9792% | +0.0000 | 0 | 0 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_10db` | 10.0 | 1 | 32.3177% | 32.3177% | +0.0000 | 0 | 0 |
| `phase_signal_defer2_gap600_3seed_10f_20261011_10db` | 10.0 | 2 | 43.4635% | 43.4635% | +0.0000 | 0 | 0 |
