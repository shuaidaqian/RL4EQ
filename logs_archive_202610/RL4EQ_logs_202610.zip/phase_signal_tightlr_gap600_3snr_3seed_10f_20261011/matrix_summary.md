# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 5.0 | 3/3 | 0.3038 | 0.0521 | 33.5373% | 33.2335% | 否 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 10.0 | 1/3 | 0.3819 | -0.0000 | 30.9201% | 30.5382% | 否 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 15.0 | 3/3 | 0.5773 | 0.1953 | 30.4601% | 29.8828% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 5.0 | 0 | 24.9479% | 24.5833% | +0.3646 | 5 | 3 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 5.0 | 1 | 29.4922% | 28.9974% | +0.4948 | 4 | 2 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 5.0 | 2 | 46.1719% | 46.1198% | +0.0521 | 1 | 1 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 10.0 | 0 | 16.9792% | 16.9792% | -0.0000 | 3 | 2 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 10.0 | 1 | 32.3177% | 32.3177% | +0.0000 | 0 | 0 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 10.0 | 2 | 43.4635% | 42.3177% | +1.1458 | 4 | 2 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 15.0 | 0 | 23.3203% | 22.0703% | +1.2500 | 3 | 2 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 15.0 | 1 | 27.8125% | 27.5260% | +0.2865 | 3 | 1 |
| `phase_signal_tightlr_gap600_3snr_3seed_10f_20261011` | 15.0 | 2 | 40.2474% | 40.0521% | +0.1953 | 2 | 2 |
