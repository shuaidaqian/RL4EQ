# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 5.0 | 3/3 | 2.0797 | 1.0200 | 38.0896% | 36.0098% | 否 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 10.0 | 2/3 | -0.3219 | -3.1141 | 29.9407% | 30.2626% | 否 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 15.0 | 3/3 | 1.0598 | 0.4015 | 29.6224% | 28.5626% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 5.0 | 0 | 28.9497% | 27.8537% | +1.0959 | 2 | 1 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 5.0 | 1 | 37.5543% | 36.5343% | +1.0200 | 2 | 2 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 5.0 | 2 | 47.7648% | 43.6415% | +4.1233 | 3 | 2 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 10.0 | 0 | 17.4262% | 16.7101% | +0.7161 | 3 | 1 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 10.0 | 1 | 28.8628% | 31.9770% | -3.1141 | 5 | 4 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 10.0 | 2 | 43.5330% | 42.1007% | +1.4323 | 2 | 2 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 15.0 | 0 | 21.5712% | 20.9744% | +0.5968 | 2 | 2 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 15.0 | 1 | 25.7487% | 25.3472% | +0.4015 | 1 | 1 |
| `state_embedding_reward64_replay_3s12f_5_10_15db_20261012` | 15.0 | 2 | 41.5473% | 39.3663% | +2.1810 | 1 | 1 |
