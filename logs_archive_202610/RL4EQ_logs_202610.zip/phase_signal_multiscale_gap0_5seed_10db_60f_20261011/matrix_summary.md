# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 0/5 | 0.0000 | 0.0000 | 0.9549% | 0.9549% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 0 | 0.9028% | 0.9028% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 1 | 0.5968% | 0.5968% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 2 | 1.6797% | 1.6797% | +0.0000 | 59 | 0 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 3 | 0.6402% | 0.6402% | +0.0000 | 60 | 1 |
| `phase_signal_multiscale_gap0_5seed_10db_60f_20261011` | 10.0 | 4 | 0.9549% | 0.9549% | +0.0000 | 59 | 0 |
