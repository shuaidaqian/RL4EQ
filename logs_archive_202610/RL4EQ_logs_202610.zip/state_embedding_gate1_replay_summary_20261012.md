# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 5.0 | 1/3 | -1.1429 | -2.9405 | 33.7023% | 34.8452% | 否 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 10.0 | 1/3 | 1.2406 | -0.3689 | 32.3966% | 31.1560% | 否 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 15.0 | 2/3 | 0.8861 | 0.0000 | 31.3983% | 30.5122% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 5.0 | 0 | 24.1428% | 24.6745% | -0.5317 | 9 | 0 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 5.0 | 1 | 28.4071% | 31.3477% | -2.9405 | 12 | 1 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 5.0 | 2 | 48.5569% | 48.5135% | +0.0434 | 4 | 1 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 10.0 | 0 | 20.0412% | 20.4102% | -0.3689 | 11 | 1 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 10.0 | 1 | 31.3043% | 31.3043% | +0.0000 | 10 | 0 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 10.0 | 2 | 45.8442% | 41.7535% | +4.0907 | 5 | 3 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 15.0 | 0 | 21.7773% | 21.7773% | +0.0000 | 10 | 0 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 15.0 | 1 | 31.6949% | 31.1089% | +0.5859 | 11 | 0 |
| `state_embedding_gate1_replay_3s12f_5_10_15db_20261012` | 15.0 | 2 | 40.7227% | 38.6502% | +2.0725 | 3 | 2 |
