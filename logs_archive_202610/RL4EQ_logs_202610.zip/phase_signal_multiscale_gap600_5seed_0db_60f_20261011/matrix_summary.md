# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 0/5 | 0.0000 | 0.0000 | 38.9644% | 38.9644% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 0 | 37.9666% | 37.9666% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 1 | 39.3273% | 39.3273% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 2 | 44.9154% | 44.9154% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 3 | 31.6536% | 31.6536% | +0.0000 | 60 | 0 |
| `phase_signal_multiscale_gap600_5seed_0db_60f_20261011` | 0.0 | 4 | 40.9592% | 40.9592% | +0.0000 | 60 | 0 |
