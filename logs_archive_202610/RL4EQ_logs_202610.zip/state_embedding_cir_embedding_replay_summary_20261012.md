# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 5.0 | 2/3 | -0.2423 | -1.5516 | 33.7023% | 33.9446% | 否 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 10.0 | 2/3 | 1.8446 | 0.0000 | 32.3966% | 30.5519% | 否 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 15.0 | 2/3 | 1.7361 | -1.2261 | 31.3983% | 29.6622% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 5.0 | 0 | 24.1428% | 23.4267% | +0.7161 | 4 | 3 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 5.0 | 1 | 28.4071% | 29.9588% | -1.5516 | 5 | 4 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 5.0 | 2 | 48.5569% | 48.4484% | +0.1085 | 1 | 1 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 10.0 | 0 | 20.0412% | 19.9002% | +0.1411 | 3 | 1 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 10.0 | 1 | 31.3043% | 31.3043% | +0.0000 | 0 | 0 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 10.0 | 2 | 45.8442% | 40.4514% | +5.3928 | 4 | 3 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 15.0 | 0 | 21.7773% | 16.3737% | +5.4036 | 1 | 1 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 15.0 | 1 | 31.6949% | 30.6641% | +1.0308 | 3 | 2 |
| `state_embedding_cir_embedding_replay_3s12f_5_10_15db_20261012` | 15.0 | 2 | 40.7227% | 41.9488% | -1.2261 | 2 | 2 |
