# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 0/5 | 0.0000 | 0.0000 | 38.9644% | 38.9644% | 否 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 4/5 | 0.3351 | -0.0629 | 29.0881% | 28.7530% | 否 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 4/5 | 0.4240 | -0.0022 | 26.6133% | 26.1892% | 否 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 3/5 | 0.0924 | -0.4210 | 25.0955% | 25.0030% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 0 | 37.9666% | 37.9666% | +0.0000 | 60 | 0 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 1 | 39.3273% | 39.3273% | +0.0000 | 60 | 0 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 2 | 44.9154% | 44.9154% | +0.0000 | 60 | 0 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 3 | 31.6536% | 31.6536% | +0.0000 | 60 | 0 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 4 | 40.9592% | 40.9592% | +0.0000 | 60 | 0 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 0 | 23.9996% | 23.9887% | +0.0109 | 24 | 14 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 1 | 30.8984% | 30.7617% | +0.1367 | 15 | 13 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 2 | 42.9319% | 42.6997% | +0.2322 | 16 | 12 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 3 | 17.9080% | 17.9709% | -0.0629 | 44 | 8 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 4 | 29.7027% | 28.3442% | +1.3585 | 22 | 12 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 0 | 18.5807% | 18.5612% | +0.0195 | 19 | 15 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 1 | 27.9622% | 27.4913% | +0.4709 | 14 | 10 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 2 | 43.9497% | 43.3268% | +0.6228 | 14 | 10 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 3 | 18.1814% | 18.1836% | -0.0022 | 48 | 3 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 4 | 24.3924% | 23.3832% | +1.0091 | 15 | 7 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 0 | 17.3307% | 17.2244% | +0.1063 | 17 | 11 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 1 | 27.8516% | 27.8885% | -0.0369 | 19 | 16 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 2 | 42.5977% | 43.0187% | -0.4210 | 21 | 16 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 3 | 14.8828% | 14.8611% | +0.0217 | 48 | 1 |
| `state_embedding_conservative_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 4 | 22.8147% | 22.0226% | +0.7921 | 16 | 9 |
