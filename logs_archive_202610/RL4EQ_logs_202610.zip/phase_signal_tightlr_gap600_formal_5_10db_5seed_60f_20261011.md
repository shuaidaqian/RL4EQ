# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 3/5 | 0.0621 | -1.4800 | 29.0881% | 29.0260% | 否 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 4/5 | 0.4774 | -0.0130 | 26.6133% | 26.1359% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 0 | 23.9996% | 23.8368% | +0.1628 | 24 | 14 |
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 1 | 30.8984% | 32.3785% | -1.4800 | 16 | 14 |
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 2 | 42.9319% | 42.5000% | +0.4319 | 18 | 13 |
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 3 | 17.9080% | 17.9774% | -0.0694 | 45 | 8 |
| `phase_signal_tightlr_gap600_5seed_5db_60f_20261011` | 5.0 | 4 | 29.7027% | 28.4375% | +1.2652 | 21 | 12 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 0 | 18.5807% | 18.5786% | +0.0022 | 19 | 14 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 1 | 27.9622% | 27.5391% | +0.4232 | 14 | 10 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 2 | 43.9497% | 42.7951% | +1.1545 | 16 | 10 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 3 | 18.1814% | 18.1944% | -0.0130 | 48 | 3 |
| `phase_signal_tightlr_gap600_5seed_10db_60f_20261011` | 10.0 | 4 | 24.3924% | 23.5720% | +0.8203 | 16 | 7 |
