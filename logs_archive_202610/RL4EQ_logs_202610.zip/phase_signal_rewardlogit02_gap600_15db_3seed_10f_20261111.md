# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_rewardlogit02_gap600_15db_3seed_10f_20261011` | 15.0 | 3/3 | 0.4253 | 0.1432 | 30.4601% | 30.0347% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_rewardlogit02_gap600_15db_3seed_10f_20261011` | 15.0 | 0 | 23.3203% | 22.3438% | +0.9766 | 2 | 2 |
| `phase_signal_rewardlogit02_gap600_15db_3seed_10f_20261011` | 15.0 | 1 | 27.8125% | 27.6693% | +0.1432 | 3 | 1 |
| `phase_signal_rewardlogit02_gap600_15db_3seed_10f_20261011` | 15.0 | 2 | 40.2474% | 40.0911% | +0.1562 | 2 | 2 |
