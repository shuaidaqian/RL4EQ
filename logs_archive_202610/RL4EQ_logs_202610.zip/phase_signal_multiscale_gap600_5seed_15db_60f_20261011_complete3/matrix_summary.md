# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 4/5 | 0.3438 | -0.1497 | 25.0955% | 24.7517% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 0 | 17.3307% | 17.4805% | -0.1497 | 18 | 12 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 1 | 27.8516% | 27.1658% | +0.6858 | 17 | 15 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 2 | 42.5977% | 42.3329% | +0.2648 | 19 | 15 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 3 | 14.8828% | 14.8286% | +0.0543 | 49 | 2 |
| `phase_signal_multiscale_gap600_5seed_15db_60f_20261011_complete3` | 15.0 | 4 | 22.8147% | 21.9510% | +0.8637 | 16 | 9 |
