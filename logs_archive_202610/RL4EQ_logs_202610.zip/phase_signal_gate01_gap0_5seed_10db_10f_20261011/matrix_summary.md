# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 2/5 | -0.0026 | -0.0521 | 0.9010% | 0.9036% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 0 | 1.0417% | 1.0938% | -0.0521 | 4 | 4 |
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 1 | 0.7813% | 0.7552% | +0.0260 | 3 | 2 |
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 2 | 1.3281% | 1.3021% | +0.0260 | 1 | 1 |
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 3 | 0.5208% | 0.5208% | +0.0000 | 3 | 3 |
| `phase_signal_gate01_gap0_5seed_10db_10f_20261011` | 10.0 | 4 | 0.8333% | 0.8464% | -0.0130 | 1 | 1 |
