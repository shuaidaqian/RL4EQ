# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 4/5 | 0.2799 | -0.0825 | 25.0955% | 24.8155% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 0 | 17.3307% | 17.3134% | +0.0174 | 47 | 2 |
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 1 | 27.8516% | 27.9340% | -0.0825 | 19 | 16 |
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 2 | 42.5977% | 41.2088% | +1.3889 | 20 | 15 |
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 3 | 14.8828% | 14.8568% | +0.0260 | 53 | 1 |
| `state_embedding_conservative_drift08_15db_5s60f_20261011` | 15.0 | 4 | 22.8147% | 22.7648% | +0.0499 | 43 | 4 |
