# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_observed_all_snr_3s6f_20261012` | 0.0 | 0/3 | 0.0000 | 0.0000 | 39.6267% | 39.6267% | 否 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 5.0 | 2/3 | 0.8898 | 0.0000 | 32.4146% | 31.5249% | 否 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 10.0 | 2/3 | 0.7885 | 0.0000 | 32.6461% | 31.8576% | 否 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 15.0 | 3/3 | 3.9424 | 0.3906 | 32.3568% | 28.4144% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_observed_all_snr_3s6f_20261012` | 0.0 | 0 | 38.7804% | 38.7804% | +0.0000 | 6 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 0.0 | 1 | 38.6502% | 38.6502% | +0.0000 | 6 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 0.0 | 2 | 41.4497% | 41.4497% | +0.0000 | 6 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 5.0 | 0 | 20.3776% | 19.3359% | +1.0417 | 3 | 1 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 5.0 | 1 | 33.4201% | 31.7925% | +1.6276 | 1 | 1 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 5.0 | 2 | 43.4462% | 43.4462% | +0.0000 | 0 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 10.0 | 0 | 17.1658% | 16.7752% | +0.3906 | 1 | 1 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 10.0 | 1 | 39.8438% | 39.8438% | +0.0000 | 0 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 10.0 | 2 | 40.9288% | 38.9540% | +1.9748 | 2 | 2 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 15.0 | 0 | 28.3854% | 17.4262% | +10.9592 | 1 | 1 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 15.0 | 1 | 31.5321% | 31.0547% | +0.4774 | 1 | 0 |
| `state_embedding_observed_all_snr_3s6f_20261012` | 15.0 | 2 | 37.1528% | 36.7622% | +0.3906 | 1 | 1 |
