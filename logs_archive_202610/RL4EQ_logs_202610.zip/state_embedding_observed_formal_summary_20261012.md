# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 0/5 | 0.0000 | 0.0000 | 38.9644% | 38.9644% | 否 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 4/5 | 0.5556 | -0.0304 | 29.0881% | 28.5326% | 否 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 4/5 | 0.7556 | -0.3559 | 26.6133% | 25.8576% | 否 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 4/5 | 0.5022 | -0.1497 | 25.0955% | 24.5933% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 0 | 37.9666% | 37.9666% | +0.0000 | 60 | 0 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 1 | 39.3273% | 39.3273% | +0.0000 | 60 | 0 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 2 | 44.9154% | 44.9154% | +0.0000 | 60 | 0 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 3 | 31.6536% | 31.6536% | +0.0000 | 60 | 0 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 0.0 | 4 | 40.9592% | 40.9592% | +0.0000 | 60 | 0 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 0 | 23.9996% | 23.8303% | +0.1693 | 18 | 13 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 1 | 30.8984% | 30.7118% | +0.1866 | 13 | 13 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 2 | 42.9319% | 42.5477% | +0.3841 | 15 | 12 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 3 | 17.9080% | 17.9384% | -0.0304 | 42 | 7 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 5.0 | 4 | 29.7027% | 27.6345% | +2.0681 | 16 | 9 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 0 | 18.5807% | 18.9366% | -0.3559 | 15 | 10 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 1 | 27.9622% | 26.2500% | +1.7122 | 12 | 10 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 2 | 43.9497% | 43.0556% | +0.8941 | 18 | 12 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 3 | 18.1814% | 18.1098% | +0.0716 | 47 | 3 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 10.0 | 4 | 24.3924% | 22.9362% | +1.4562 | 14 | 8 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 0 | 17.3307% | 15.8615% | +1.4692 | 12 | 9 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 1 | 27.8516% | 28.0013% | -0.1497 | 16 | 13 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 2 | 42.5977% | 42.1224% | +0.4753 | 16 | 13 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 3 | 14.8828% | 14.8003% | +0.0825 | 48 | 2 |
| `state_embedding_observed_formal_5s60f_0_5_10_15db_20261012` | 15.0 | 4 | 22.8147% | 22.1810% | +0.6337 | 13 | 9 |
