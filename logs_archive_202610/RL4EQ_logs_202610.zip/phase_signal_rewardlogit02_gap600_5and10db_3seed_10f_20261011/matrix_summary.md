# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 5.0 | 3/3 | 0.4080 | 0.0260 | 33.5373% | 33.1293% | 否 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 10.0 | 2/3 | 0.3950 | 0.0000 | 30.9201% | 30.5252% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 5.0 | 0 | 24.9479% | 24.4010% | +0.5469 | 5 | 3 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 5.0 | 1 | 29.4922% | 28.8411% | +0.6510 | 4 | 2 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 5.0 | 2 | 46.1719% | 46.1458% | +0.0260 | 1 | 1 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 10.0 | 0 | 16.9792% | 16.9401% | +0.0391 | 3 | 2 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 10.0 | 1 | 32.3177% | 32.3177% | +0.0000 | 0 | 0 |
| `phase_signal_rewardlogit02_gap600_5and10db_3seed_10f_20261011` | 10.0 | 2 | 43.4635% | 42.3177% | +1.1458 | 4 | 2 |
