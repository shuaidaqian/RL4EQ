# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 3/5 | 0.3385 | -0.0391 | 24.9674% | 24.6289% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 0 | 19.2773% | 18.9648% | +0.3125 | 6 | 2 |
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 1 | 28.7630% | 28.4505% | +0.3125 | 5 | 4 |
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 2 | 39.4206% | 38.3138% | +1.1068 | 9 | 6 |
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 3 | 12.9818% | 12.9818% | +0.0000 | 17 | 0 |
| `state_embedding_conservative_15db_5s20f_20261011` | 15.0 | 4 | 24.3945% | 24.4336% | -0.0391 | 1 | 1 |
