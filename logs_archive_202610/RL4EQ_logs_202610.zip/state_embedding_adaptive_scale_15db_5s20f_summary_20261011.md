# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 3/5 | 0.9115 | -0.3255 | 24.9674% | 24.0560% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 0 | 19.2773% | 15.8268% | +3.4505 | 5 | 2 |
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 1 | 28.7630% | 27.9492% | +0.8138 | 5 | 4 |
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 2 | 39.4206% | 38.8021% | +0.6185 | 6 | 4 |
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 3 | 12.9818% | 12.9818% | +0.0000 | 17 | 0 |
| `state_embedding_adaptive_scale_15db_5s20f_20261011` | 15.0 | 4 | 24.3945% | 24.7201% | -0.3255 | 1 | 1 |
