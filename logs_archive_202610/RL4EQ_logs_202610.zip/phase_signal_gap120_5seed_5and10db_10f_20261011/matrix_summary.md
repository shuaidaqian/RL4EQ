# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 0/5 | 0.0000 | 0.0000 | 9.5547% | 9.5547% | 否 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 0/5 | -0.0833 | -0.4167 | 4.5078% | 4.5911% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 0 | 8.2943% | 8.2943% | +0.0000 | 9 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 1 | 9.2057% | 9.2057% | +0.0000 | 9 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 2 | 14.0234% | 14.0234% | +0.0000 | 9 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 3 | 5.5729% | 5.5729% | +0.0000 | 10 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 5.0 | 4 | 10.6771% | 10.6771% | +0.0000 | 9 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 0 | 3.5677% | 3.5677% | +0.0000 | 10 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 1 | 4.0885% | 4.0885% | +0.0000 | 9 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 2 | 8.5156% | 8.9323% | -0.4167 | 10 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 3 | 1.7578% | 1.7578% | +0.0000 | 10 | 0 |
| `phase_signal_gap120_5seed_5and10db_10f_20261011` | 10.0 | 4 | 4.6094% | 4.6094% | +0.0000 | 10 | 0 |
