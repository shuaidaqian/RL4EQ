# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 5.0 | 2/3 | 0.1157 | 0.0000 | 51.6638% | 51.5480% | 否 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 10.0 | 2/3 | 0.1374 | 0.0000 | 52.4233% | 52.2859% | 否 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 5.0 | 3/3 | 0.3038 | 0.0217 | 51.6638% | 51.3600% | 否 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 10.0 | 3/3 | 0.2604 | 0.0434 | 52.4233% | 52.1629% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 5.0 | 0 | 51.1719% | 51.1719% | +0.0000 | 6 | 1 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 5.0 | 1 | 50.9115% | 50.7378% | +0.1736 | 6 | 0 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 5.0 | 2 | 52.9080% | 52.7344% | +0.1736 | 6 | 1 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 10.0 | 0 | 52.4957% | 52.4957% | +0.0000 | 6 | 1 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 10.0 | 1 | 51.7578% | 51.4974% | +0.2604 | 6 | 0 |
| `state_embedding_replay_baseline_3s6f_5_10db_20261011` | 10.0 | 2 | 53.0165% | 52.8646% | +0.1519 | 6 | 1 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 5.0 | 0 | 51.1719% | 51.1502% | +0.0217 | 6 | 1 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 5.0 | 1 | 50.9115% | 50.2821% | +0.6293 | 6 | 0 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 5.0 | 2 | 52.9080% | 52.6476% | +0.2604 | 6 | 1 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 10.0 | 0 | 52.4957% | 52.4523% | +0.0434 | 6 | 1 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 10.0 | 1 | 51.7578% | 51.2370% | +0.5208 | 6 | 0 |
| `state_embedding_replay_conditioned_3s6f_5_10db_20261011` | 10.0 | 2 | 53.0165% | 52.7995% | +0.2170 | 6 | 1 |
