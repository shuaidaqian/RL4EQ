# 在线 PEFT 矩阵自动汇总

该表由 `scripts/summarize_online_matrix.py` 从 `frame_metrics.jsonl` 生成。
改善值定义为 `(Frozen BER - Online BER) × 100`，单位是百分点。

## SNR 汇总

| 日志目录 | SNR | 正收益 seed | 平均改善 (pp) | 最差 seed 改善 (pp) | Frozen BER | Online BER | 在线使用 Data 标签 |
|---|---:|---:|---:|---:|---:|---:|---|
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 5.0 | 3/3 | 0.5281 | 0.0434 | 33.7023% | 33.1742% | 否 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 10.0 | 1/3 | 1.6638 | -0.1194 | 32.3966% | 30.7328% | 否 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 15.0 | 3/3 | 2.8429 | 0.9006 | 31.3983% | 28.5554% | 否 |

## Seed 配对明细

| 日志目录 | SNR | seed | Frozen BER | Online BER | 改善 (pp) | 接受更新 | 回滚 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 5.0 | 0 | 24.1428% | 23.4918% | +0.6510 | 5 | 4 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 5.0 | 1 | 28.4071% | 27.5174% | +0.8898 | 5 | 4 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 5.0 | 2 | 48.5569% | 48.5135% | +0.0434 | 1 | 1 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 10.0 | 0 | 20.0412% | 20.1606% | -0.1194 | 4 | 2 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 10.0 | 1 | 31.3043% | 31.3043% | +0.0000 | 0 | 0 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 10.0 | 2 | 45.8442% | 40.7335% | +5.1107 | 6 | 4 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 15.0 | 0 | 21.7773% | 16.2218% | +5.5556 | 2 | 2 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 15.0 | 1 | 31.6949% | 30.7943% | +0.9006 | 2 | 1 |
| `state_embedding_adaptive_replay_3s12f_5_10_15db_20261012` | 15.0 | 2 | 40.7227% | 38.6502% | +2.0725 | 3 | 2 |
